# Sistema de Pedidos para Restaurante

Este proyecto gestiona menús, pedidos y pagos en un restaurante usando consola o interfaz gráfica.
