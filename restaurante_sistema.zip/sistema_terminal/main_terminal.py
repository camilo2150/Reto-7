from collections import deque
from gestor.menu_manager import MenuManager
from modelo.item import MainCourse, Beverage, Dessert
from modelo.pedido import Order, Payment

if __name__ == "__main__":
    orders_queue = deque()
    menu_manager = MenuManager()

    print("Bienvenido al sistema de pedidos")

    while True:
        print("\n1. Ver menú\n2. Agregar ítem al menú\n3. Editar ítem\n4. Eliminar ítem")
        print("5. Crear nueva orden\n6. Atender próxima orden\n7. Salir")

        op = input("Elige una opción: ")

        if op == "1":
            menu_manager.list_menu()

        elif op == "2":
            name = input("Nombre del ítem: ")
            price = float(input("Precio: "))
            item_type = input("Tipo (MainCourse / Beverage / Dessert): ")
            menu_manager.create_item(name, price, item_type)

        elif op == "3":
            name = input("Nombre del ítem a editar: ")
            new_price = input("Nuevo precio (deja vacío si no cambia): ")
            new_type = input("Nuevo tipo (deja vacío si no cambia): ")
            menu_manager.update_item(
                name,
                float(new_price) if new_price else None,
                new_type if new_type else None,
            )

        elif op == "4":
            name = input("Nombre del ítem a eliminar: ")
            menu_manager.delete_item(name)

        elif op == "5":
            order = Order()
            while True:
                menu_manager.list_menu()
                choice = input("Número del ítem a agregar (0 para terminar): ")
                if choice == "0":
                    break
                item_data = menu_manager.get_item_by_number(int(choice))
                if item_data:
                    if item_data.type == "MainCourse":
                        order.add_item(MainCourse(item_data.name, item_data.price))
                    elif item_data.type == "Beverage":
                        order.add_item(Beverage(item_data.name, item_data.price))
                    elif item_data.type == "Dessert":
                        order.add_item(Dessert(item_data.name, item_data.price))
                else:
                    print("Opción inválida.")

            orders_queue.append(order)
            print("Orden agregada a la cola.\n")

        elif op == "6":
            if orders_queue:
                next_order = orders_queue.popleft()
                metodo = input("Método de pago (Tarjeta / Efectivo): ")
                Payment(next_order, metodo).process_payment()
            else:
                print("No hay órdenes pendientes.")

        elif op == "7":
            print("¡Hasta luego!")
            break

        else:
            print("Opción no válida.")
