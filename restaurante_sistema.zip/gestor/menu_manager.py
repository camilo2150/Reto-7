import json
from collections import namedtuple

MenuItemData = namedtuple("MenuItemData", ["name", "price", "type"])

class MenuManager:
    def __init__(self, filename="menu.json"):
        self.filename = filename
        self.menu = self.load_menu()

    def load_menu(self):
        try:
            with open(self.filename, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def save_menu(self):
        with open(self.filename, "w") as f:
            json.dump(self.menu, f, indent=4)

    def create_item(self, name, price, item_type):
        self.menu[name] = {"price": price, "type": item_type}
        self.save_menu()

    def update_item(self, name, new_price=None, new_type=None):
        if name in self.menu:
            if new_price is not None:
                self.menu[name]["price"] = new_price
            if new_type is not None:
                self.menu[name]["type"] = new_type
            self.save_menu()

    def delete_item(self, name):
        if name in self.menu:
            del self.menu[name]
            self.save_menu()

    def list_menu(self):
        print("\n--- MENÚ ACTUAL ---")
        for i, (name, data) in enumerate(self.menu.items(), 1):
            print(f"{i}. {name} (${data['price']}) [{data['type']}]")

    def get_item_by_number(self, number):
        items = list(self.menu.items())
        if 0 < number <= len(items):
            name, data = items[number - 1]
            return MenuItemData(name, data["price"], data["type"])
        return None
